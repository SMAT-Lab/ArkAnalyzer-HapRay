    使用pip install安装目录下的四个pip安装包
    由于存在依赖关系，请按照以下顺序安装
    xdevice, xdevice-devicetest, xdevice-ohos, hypium
    安装命令:
    pip install xdevice-6.0.7.210.tar.gz
    pip install xdevice-devicetest-6.0.7.210.tar.gz
    pip install xdevice-ohos-6.0.7.210.tar.gz
    pip install hypium-6.0.7.210.tar.gz
    