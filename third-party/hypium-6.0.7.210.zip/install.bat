cd /d %~dp0
cd
REM 设置python解释器路径
set python="python"
%python% -m pip uninstall -y hypium
%python% -m pip uninstall -y xdevice-ohos
%python% -m pip uninstall -y xdevice-devicetest
%python% -m pip uninstall -y xdevice

%python% -m pip install xdevice-6.0.7.210.tar.gz
%python% -m pip install xdevice-devicetest-6.0.7.210.tar.gz
%python% -m pip install xdevice-ohos-6.0.7.210.tar.gz
%python% -m pip install hypium-6.0.7.210.tar.gz
pause